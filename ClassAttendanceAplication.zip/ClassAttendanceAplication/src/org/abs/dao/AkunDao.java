/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package org.abs.dao;

import java.util.List;
import javafx.beans.value.ObservableValue;
import javafx.scene.control.TableColumn;
import javafx.util.Callback;
import org.abs.dao.impl.AkunDaoImpl;
import org.abs.model.Akun;

/**
 *
 * @author norlinapasaribu
 */
public interface AkunDao {
   public void saveDataAkun(Akun a);
   public Akun getDataAkun(String username);
   public List<Akun> getAllAkun();
   public void saveDataPendaftaran(Akun akun);
   public List<Akun> getAllPendaftaran();
//    public String getJeniskelamin(int id);
    public boolean checkUser(String user);
    public void update(Akun akun);
    public boolean login(String username, String password);
    public boolean loginKu(String username, String password);
   public String getWaktu();
   public String getTanggal();
  public void  deleteDataAkun(Akun a);
  public void delete(String user);

//    public Callback<TableColumn.CellDataFeatures<AkunDaoImpl, String>, ObservableValue<String>> getWaktu(Akun akun);
}
