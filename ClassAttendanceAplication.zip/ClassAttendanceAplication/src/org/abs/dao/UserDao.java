/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package org.abs.dao;

import java.util.List;
import org.abs.model.User;

/**
 *
 * @author norlinapasaribu
 */
public interface UserDao {
   public void saveDataAnggota(User a);
   public User getDataAnggota(String Id);
   public List<User> getAllAnggota();
    
}
