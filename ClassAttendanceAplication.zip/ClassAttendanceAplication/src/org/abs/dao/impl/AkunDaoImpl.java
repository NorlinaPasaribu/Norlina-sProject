/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package org.abs.dao.impl;

import java.text.DateFormat;
import java.text.SimpleDateFormat;
import java.util.Date;
import java.util.List;
import javafx.beans.value.ObservableValue;
import javafx.scene.control.TableColumn;
import javafx.util.Callback;
import org.abs.dao.AkunDao;
import org.abs.model.Akun;
import org.abs.util.HibernateUtil;
import org.hibernate.Session;

/**
 *
 * @author norlinapasaribu
 */
public class AkunDaoImpl implements AkunDao {
    private Object session;
     @Override
    public void saveDataAkun (Akun a) {
      Session session = HibernateUtil.getSession();
      session.getTransaction().begin();
      session.save(a);
      session.getTransaction().commit();
      HibernateUtil.closeSession();
    }
    
    public void updateDataAkun (Akun a) {
      Session session = HibernateUtil.getSession();
      session.getTransaction().begin();
      session.update(a);
      session.getTransaction().commit();
      HibernateUtil.closeSession();
    }

    @Override
    public Akun getDataAkun(String username) {
        Session session = HibernateUtil.getSession();
        session.getTransaction().begin();
        Akun a = (Akun)session.get(Akun.class, username);
        session.getTransaction().commit();
        HibernateUtil.closeSession();
        return a;
    }

    @Override
    public List<Akun> getAllAkun() {
    Session session = HibernateUtil.getSession();
    session.getTransaction().begin();
    List<Akun> Akuns = session.createCriteria(Akun.class).list();
    session.getTransaction().commit();
    return Akuns;
    }
    
    @Override
    public void saveDataPendaftaran(Akun akun) {
        Session session = HibernateUtil.getSession();
        session.getTransaction().begin();
        session.save(akun);
        session.getTransaction().commit();
        HibernateUtil.closeSession();
    }

    @Override
    public List<Akun> getAllPendaftaran() {
        Session session = HibernateUtil.getSession();
        session.getTransaction().begin();
        List<Akun>akuns = session.createCriteria(Akun.class).list();
        session.getTransaction().commit();
        return akuns;
    }
    
    @Override
    public boolean login(String user, String pass) {
        boolean login = false;
        List<Akun> akuns = getAllPendaftaran();
        //System.out.println("ok");
        for (Akun akun : akuns) {
            //System.out.println(akun.getUserName().equals(user)+"  "+ akun.getPassword().equals(pass));
            if (akun.getUserName().equals(user) && akun.getPassword().equals(pass))
            {
                login = true;
                break;
            }
        }
        return login;
    }
    
      @Override
    public boolean loginKu(String user, String pass) {
        boolean login = false;
        List<Akun> akuns = getAllAkun();
        //System.out.println("Pendaftaran");
        for (Akun akun : akuns) {
            if (user.equalsIgnoreCase("admin")&&pass.equalsIgnoreCase("admin"))
            {
                login = true;
                break;
            }
        }
        return login;
    }
    
    
    @Override
    public boolean checkUser(String user) 
    {
        boolean username = false;
        Session session = HibernateUtil.getSession();
        session.getTransaction().begin();
        List<Akun> akuns = getAllAkun();
        for (Akun a : akuns) {
            if (a.getUserName().equalsIgnoreCase(user))
            {
                username = true;
                break;
            }
        }
        return username;
    }

//    @Override
//    public void getTanggal(Akun a) {
//        throw new UnsupportedOperationException("Not supported yet."); //To change body of generated methods, choose Tools | Templates.
//    }
//
//    @Override
//    public void getWaktu(Akun a) {
//        throw new UnsupportedOperationException("Not supported yet."); //To change body of generated methods, choose Tools | Templates.
//    }
    
     @Override  
     public String getTanggal() {  
        DateFormat dateFormat = new SimpleDateFormat("yyyy/MM/dd");  
        Date date = new Date();  
        return dateFormat.format(date);  
    }  
     
     @Override
    public String getWaktu() {  
        DateFormat dateFormat = new SimpleDateFormat("HH:mm:ss");  
        Date date = new Date();  
        return dateFormat.format(date);  
    } 
    
     @Override
    public void deleteDataAkun(Akun a) 
    {
        for(Akun akuns : getAllAkun())
        {
            if(akuns.getUserName().equalsIgnoreCase(a.getUserName()))
            {
                Session session = HibernateUtil.getSession();
                session.getTransaction().begin();
                session.delete(akuns);
                session.getTransaction().commit();
                HibernateUtil.closeSession();
                break;
            }
//            else
//            {
//                System.out.println("Gagal didelete ya. Hiks..");
//            }
        }
        
    }
    
     @Override
    public void delete(String user)
    {
        for(Akun a : getAllAkun())
        {
            if(a.getUserName().equalsIgnoreCase(user))
            {
                Akun akun = new Akun(user, a.getPassword());
                deleteDataAkun(akun);
            }
        }
    }
    
    @Override
    public void update(Akun akun)
    {  
        for(Akun a : getAllAkun())
        {
            if(a.getUserName().equalsIgnoreCase(akun.getUserName()))
            {
                a.setUserName(akun.getUserName());
                a.setPassword(akun.getPassword()); 
                updateDataAkun(a);
            }
            
        }
    }

}
