/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package org.abs.dao.impl;

import java.text.DateFormat;
import java.text.SimpleDateFormat;
import java.util.Date;
import java.util.List;
import org.abs.dao.DataAbsensiDao;
import org.abs.model.Akun;
import org.abs.model.DataAbsensi;
import org.abs.util.HibernateUtil;
import org.hibernate.Session;

/**
 *
 * @author norlinapasaribu
 */
public class DataAbsensiDaoImpl implements DataAbsensiDao{
      @Override
    public void saveDataAbsensi (DataAbsensi a) {
      Session session = HibernateUtil.getSession();
      session.getTransaction().begin();
      session.save(a);
      session.getTransaction().commit();
      HibernateUtil.closeSession();
    }

    @Override
    public DataAbsensi getDataAbsensi(String idDataAbsensi) {
        Session session = HibernateUtil.getSession();
        session.getTransaction().begin();
        DataAbsensi a = (DataAbsensi)session.get(DataAbsensi.class, idDataAbsensi);
        session.getTransaction().commit();
        HibernateUtil.closeSession();
        return a;
    }

    @Override
    public List<DataAbsensi> getAllDataAbsensi() {
    Session session = HibernateUtil.getSession();
    session.getTransaction().begin();
    List<DataAbsensi> DataAbsensis = session.createCriteria(DataAbsensi.class).list();
    session.getTransaction().commit();
    return DataAbsensis
            ;
    }
     @Override
    public boolean login(String user, String pass) {
        boolean login = false;
        //System.out.println("gfgfhf");
//        Session session = HibernateUtil.getSession();
//        System.out.println("aaaaaa");
//        session.getTransaction().begin();
//        System.out.println("hadbha");
        List<DataAbsensi> dataAbsensis = getAllDataAbsensi();
        //System.out.println("Pendaftaran");
        for (DataAbsensi dataAbsensi : dataAbsensis) {
            if (dataAbsensi.getUsername().equals(user) && dataAbsensi.getPassword().equals(pass))
            {
                login = true;
                break;
            }
        }
        return login;
    }
    
      @Override
    public boolean loginKu(String user, String pass) {
        boolean login = false;
        //System.out.println("gfgfhf");
//        Session session = HibernateUtil.getSession();
//        System.out.println("aaaaaa");
//        session.getTransaction().begin();
//        System.out.println("hadbha");
        List<DataAbsensi> akuns = getAllDataAbsensi();
        //System.out.println("Pendaftaran");
        for (DataAbsensi akun : akuns) {
            if (user.equalsIgnoreCase("admin")&&pass.equalsIgnoreCase("admin"))
            {
                login = true;
                break;
            }
        }
        return login;
    }
    
    
    @Override
    public boolean checkUser(String user) 
    {
        boolean username = false;
        Session session = HibernateUtil.getSession();
        session.getTransaction().begin();
        List<DataAbsensi>dataAbsensis = getAllDataAbsensi();
        for (DataAbsensi a : dataAbsensis) {
            if (a.getUsername().equalsIgnoreCase(user))
            {
                username = true;
                break;
            }
        }
        return username;
    }
    @Override
    public String getWaktu() {  
        DateFormat dateFormat = new SimpleDateFormat("HH:mm:ss");  
        Date date = new Date();  
        return dateFormat.format(date);  
    } 
    

}
