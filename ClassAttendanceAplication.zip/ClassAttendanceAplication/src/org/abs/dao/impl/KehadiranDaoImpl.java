/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package org.abs.dao.impl;

import java.text.DateFormat;
import java.text.SimpleDateFormat;
import java.util.Date;
import java.util.List;
import org.abs.dao.KehadiranDao;
import org.abs.model.Kehadiran;
import org.abs.util.HibernateUtil;
import org.hibernate.Session;

/**
 *
 * @author norlinapasaribu
 */
public class KehadiranDaoImpl implements KehadiranDao {
      @Override
    public void saveDataKehadiran (Kehadiran a) {
      Session session = HibernateUtil.getSession();
      session.getTransaction().begin();
      session.save(a);
      session.getTransaction().commit();
      HibernateUtil.closeSession();
    }

    @Override
    public Kehadiran getDataKehadiran(String idKehadiran) {
        Session session = HibernateUtil.getSession();
        session.getTransaction().begin();
        Kehadiran a = (Kehadiran)session.get(Kehadiran.class, idKehadiran);
        session.getTransaction().commit();
        HibernateUtil.closeSession();
        return a;
    }

    @Override
    public List<Kehadiran> getAllKehadiran() {
    Session session = HibernateUtil.getSession();
    session.getTransaction().begin();
    List<Kehadiran> Kehadirans = session.createCriteria(Kehadiran.class).list();
    session.getTransaction().commit();
    return Kehadirans;
    }
    @Override
    public String getWaktu() {  
        DateFormat dateFormat = new SimpleDateFormat("HH:mm:ss");  
        Date date = new Date();  
        return dateFormat.format(date);  
    } 

}
