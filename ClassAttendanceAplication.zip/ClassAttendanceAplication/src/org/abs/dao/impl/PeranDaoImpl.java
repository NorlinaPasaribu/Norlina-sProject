/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package org.abs.dao.impl;

import java.util.List;
import org.abs.dao.PeranDao;
import org.abs.model.Peran;
import org.abs.util.HibernateUtil;
import org.hibernate.Session;

/**
 *
 * @author norlinapasaribu
 */
public class PeranDaoImpl implements PeranDao {
   @Override
    public void saveDataPeran (Peran a) {
      Session session = HibernateUtil.getSession();
      session.getTransaction().begin();
      session.save(a);
      session.getTransaction().commit();
      HibernateUtil.closeSession();
    }

    @Override
    public Peran getDataPeran(String idPeran) {
        Session session = HibernateUtil.getSession();
        session.getTransaction().begin();
        Peran a = (Peran)session.get(Peran.class, idPeran);
        session.getTransaction().commit();
        HibernateUtil.closeSession();
        return a;
    }

    @Override
    public List<Peran> getAllPeran() {
    Session session = HibernateUtil.getSession();
    session.getTransaction().begin();
    List<Peran> Perans = session.createCriteria(Peran.class).list();
    session.getTransaction().commit();
    return Perans;
    }

   

   
}
