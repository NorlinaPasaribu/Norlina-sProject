/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package org.abs.dao.impl;

import java.util.List;
import org.abs.dao.UserDao;
import org.abs.model.User;
import org.abs.util.HibernateUtil;
import org.hibernate.Session;

/**
 *
 * @author norlinapasaribu
 */
public class UserDaoImpl implements UserDao{
    @Override
    public void saveDataAnggota(User a) {
      Session session = HibernateUtil.getSession();
      session.getTransaction().begin();
      session.save(a);
      session.getTransaction().commit();
      HibernateUtil.closeSession();
    }

    @Override
    public User getDataAnggota(String Id) {
        Session session = HibernateUtil.getSession();
        session.getTransaction().begin();
        User a = (User)session.get(User.class, Id);
        session.getTransaction().commit();
        HibernateUtil.closeSession();
        return a;
    }

    @Override
    public List<User> getAllAnggota() {
    Session session = HibernateUtil.getSession();
    session.getTransaction().begin();
    List<User> Anggotas = session.createCriteria(User.class).list();
    session.getTransaction().commit();
    return Anggotas;
    }
}
