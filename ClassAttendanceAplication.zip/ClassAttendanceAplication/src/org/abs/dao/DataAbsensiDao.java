/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package org.abs.dao;

import java.util.List;
import org.abs.model.DataAbsensi;

/**
 *
 * @author norlinapasaribu
 */
public interface DataAbsensiDao {
   public void saveDataAbsensi(DataAbsensi a);
   public DataAbsensi getDataAbsensi(String idDataAbsensi);
   public List<DataAbsensi> getAllDataAbsensi();
   public boolean checkUser(String user);
    public boolean login(String username, String password);
    public boolean loginKu(String username, String password);
      public String getWaktu();
}
