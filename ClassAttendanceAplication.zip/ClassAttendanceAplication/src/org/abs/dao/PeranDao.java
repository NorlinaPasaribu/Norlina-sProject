/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package org.abs.dao;

import java.util.List;
import org.abs.model.Peran;

/**
 *
 * @author norlinapasaribu
 */
public interface PeranDao {
   public void saveDataPeran(Peran a);
   public Peran getDataPeran(String idPeran);
   public List<Peran> getAllPeran();
}
