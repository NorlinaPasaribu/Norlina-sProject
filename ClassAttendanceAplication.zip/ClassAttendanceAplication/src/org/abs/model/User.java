/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package org.abs.model;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.Id;
import javax.persistence.Table;

/**
 *
 * @author norlinapasaribu
 */

@Entity
@Table(name="user")
public class User {
@Id
@Column(name = "Id")
private String Id;
@Column (name = "Nama")
private String nama;
@Column(name = "Alamat")
private String alamat;
@Column(name = "Pekerjaan")
private String peranan;
@Column(name = " Jenis Kelamin")
private String jenisKelamin;
@Column(name= " Tanggal Lahir")
private String tanggalLahir;


    public User() {
    }

    public User(String Id, String nama, String alamat, String peranan, String jenisKelamin, String tanggalLahir) {
        this.nama = nama;
        this.alamat = alamat;
        this.peranan = peranan;
        this.jenisKelamin = jenisKelamin;
        this.tanggalLahir = tanggalLahir;
        this.Id = Id;
    }

    public String getNama() {
        return nama;
    }

    public void setNama(String nama) {
        this.nama = nama;
    }

    public String getAlamat() {
        return alamat;
    }

    public void setAlamat(String alamat) {
        this.alamat = alamat;
    }

    public String getPeranan() {
        return peranan;
    }

    public void setPeranan(String peranan) {
        this.peranan = peranan;
    }

    public String getJenisKelamin() {
        return jenisKelamin;
    }

    public void setJenisKelamin(String jenisKelamin) {
        this.jenisKelamin = jenisKelamin;
    }

    public String getTanggalLahir() {
        return tanggalLahir;
    }

    public void setTanggalLahir(String tanggalLahir) {
        this.tanggalLahir = tanggalLahir;
    }

    public String getId() {
        return Id;
    }

    public void setId(String Id) {
        this.Id = Id;
    }
    
    





    
}
