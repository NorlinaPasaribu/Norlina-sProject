/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package org.abs.model;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.Id;
import javax.persistence.Table;

/**
 *
 * @author norlinapasaribu
 */
@Entity
@Table(name="peran")
public class Peran {
    
    @Id
    @Column(name = "idPeran")
    private String idPeran;
    @Column(name = "namaPeran")
    private String namaPeran;

    public String getId() {
        return idPeran;
    }

    public void setId(String id) {
        this.idPeran = id;
    }

    public String getNamaPeran() {
        return namaPeran;
    }

    public void setNamaPeran(String namaPeran) {
        this.namaPeran = namaPeran;
    }

    public Peran(String id, String namaPeran) {
        this.idPeran = id;
        this.namaPeran = namaPeran;
    }

    public Peran() {
    }
    
    
}
