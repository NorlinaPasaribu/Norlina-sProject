/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package org.abs.model;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.Table;

/**
 *
 * @author norlinapasaribu
 */
@Entity
@Table(name="kehadiran")
public class Kehadiran {
    @Id
    @Column(name = "No")
    @GeneratedValue(strategy = GenerationType.IDENTITY)
    private int no;
    @Column(name = "Mahasiswa")
    private String mahasiswa;
    @Column(name = "Keterangan")
    private String keterangan;

    public Kehadiran() {
        
    }

    
    
    public Kehadiran(String no, String mahasiswa, String keterangan) {
        no = no;
        this.mahasiswa = mahasiswa;
        this.keterangan = keterangan;
    }

    public Kehadiran(String text, String text0) {
        throw new UnsupportedOperationException("Not supported yet."); //To change body of generated methods, choose Tools | Templates.
    }
    
    

    public int getNo() {
        return no;
    }

    public void setNo(String no) {
        no = no;
    }

    public String getMahasiswa() {
        return mahasiswa;
    }

    public void setMahasiswa(String mahasiswa) {
        this.mahasiswa = mahasiswa;
    }

    public String getKeterangan() {
        return keterangan;
    }

    public void setKeterangan(String keterangan) {
        this.keterangan = keterangan;
    }

   
    
    
}
