
package org.abs.controller;

import java.net.URL;
import java.util.List;
import java.util.ResourceBundle;
import javafx.collections.FXCollections;
import javafx.collections.ObservableList;
import javafx.fxml.FXML;
import javafx.scene.control.TableColumn;
import javafx.scene.control.TableView;
import javafx.scene.control.cell.PropertyValueFactory;
import javax.persistence.EntityManager;
import javax.persistence.EntityManagerFactory;
import javax.persistence.EntityNotFoundException;
import javax.persistence.NoResultException;
import javax.persistence.Query;
import javax.persistence.criteria.CriteriaQuery;
import javax.persistence.criteria.Root;
import org.abs.dao.DataAbsensiDao;
import org.abs.dao.impl.DataAbsensiDaoImpl;
import org.abs.model.DataAbsensi;

/**
 *
 * @author norlinapasaribu
 */
public class DataAbsensiController {
 dataAbsensi;
@FXML
    private TableView<DataAbsensi> dataTB;
    @FXML
    private TableColumn<DataAbsensi, String> idTC;
    @FXML
    private TableColumn<DataAbsensi, String> namaTC;
    @FXML
    private TableColumn<DataAbsensi, String> passTC;

    private DataAbsensiDao absensiDao;
    ObservableList<DataAbsensi> dataAbsensi;

    public DataAbsensiController()
    {
        absensiDao = new DataAbsensiDaoImpl();
    }

    /**
     * Initializes the controller class.
     */

    public void initialize(URL url, ResourceBundle rb)
    {
        loadData();
    }
    public void loadData()
    {
        List<DataAbsensi> akuns = absensiDao.getAllDataAbsensi();
        dataAbsensi = FXCollections.observableArrayList(akuns);
        namaTC.setCellValueFactory(new PropertyValueFactory<DataAbsensi, String>("nama"));
        idTC.setCellValueFactory(new PropertyValueFactory<DataAbsensi, String>("username"));
        passTC.setCellValueFactory(new PropertyValueFactory<DataAbsensi, String>("password"));
        dataTB.setItems(dataAbsensi);
    }
}
