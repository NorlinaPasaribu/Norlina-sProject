/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package org.abs.controller;

import java.io.IOException;
import java.net.URL;
import java.util.List;
import java.util.ResourceBundle;
import javafx.collections.FXCollections;
import javafx.collections.ObservableList;
import javafx.event.ActionEvent;
import javafx.fxml.FXML;
import javafx.fxml.FXMLLoader;
import javafx.scene.Parent;
import javafx.scene.Scene;
import javafx.scene.control.Button;
import javafx.scene.control.RadioButton;
import javafx.scene.control.TableColumn;
import javafx.scene.control.TableView;
import javafx.scene.control.TextField;
import javafx.scene.control.ToggleGroup;
import javafx.scene.control.cell.PropertyValueFactory;
import javafx.stage.Stage;
import javax.swing.JOptionPane;
import org.abs.dao.AkunDao;
import org.abs.dao.UserDao;
import org.abs.dao.impl.AkunDaoImpl;
import org.abs.driver.Driver;
import org.abs.model.Akun;
import org.abs.model.User;
import java.util.Date;
import java.text.DateFormat;
import java.text.SimpleDateFormat;
import java.time.LocalDate;
import javafx.fxml.Initializable;
import javafx.scene.Node;
import javafx.scene.control.ComboBox;
import javafx.scene.control.MenuButton;
import org.abs.dao.DataAbsensiDao;
import org.abs.dao.KehadiranDao;
import org.abs.dao.impl.DataAbsensiDaoImpl;
import org.abs.dao.impl.KehadiranDaoImpl;
import org.abs.model.DataAbsensi;
import org.abs.model.Kehadiran;

/**
 *
 * @author norlinapasaribu
 */
public class LoginSController implements Initializable
{

    @FXML
    private TextField userNameTF;
    @FXML
    private TextField passwordTF;
    @FXML
    private TextField usernameloginTF;
    @FXML
    private TextField passwordloginTF;
    @FXML
    private TextField IdTF;
    @FXML
    private TextField tanggallahirTF;
    @FXML
    private RadioButton radioPria;
    @FXML
    private RadioButton radioWanita;
    @FXML
    private Button konfirmasibutton;
    @FXML
    private Button Daftar;
    @FXML
    private Button Login;

    @FXML
    private ToggleGroup jkl;

    @FXML
    private TableView<DataAbsensi> daftarTB;
     @FXML
    private TableView<Kehadiran> SuksesMasukTB;
    @FXML
    private TableColumn<AkunDaoImpl, String> userName;
    @FXML
    private TableColumn<AkunDaoImpl, String> password;
    @FXML
    private TableColumn<DataAbsensiDaoImpl, String> userNameTC;
    @FXML
    private TableColumn<DataAbsensiDaoImpl, String> keteranganTC;


    @FXML
    private ComboBox levelCB;

    Driver d = new Driver();

    private DataAbsensiDao daDao;

    ObservableList<DataAbsensi> dataAbsen;

    ObservableList<Akun> dataPendaftaran;
    private AkunDao akunDao;


    ObservableList<String> tipe = FXCollections.observableArrayList("Pria", "Wanita");

    public LoginSController() {
        akunDao = new AkunDaoImpl();
        daDao = new DataAbsensiDaoImpl();
        daftarTB = new TableView<>();
       SuksesMasukTB = new TableView<>();

    }

    public void setData()
    {
        levelCB.getItems().addAll("Mahasiswa", "Admin");

    }



     public void loadData1() {
        List<DataAbsensi>datas = daDao.getAllDataAbsensi();
        dataAbsen = FXCollections.observableArrayList(datas);
        userNameTC.setCellValueFactory(new PropertyValueFactory<DataAbsensiDaoImpl, String>("Nama"));
        keteranganTC.setCellValueFactory(new PropertyValueFactory<DataAbsensiDaoImpl, String>("Password"));
        daftarTB.setItems(dataAbsen);

    }


    private void inisialAwalInputan() {
        userNameTC.setText("");
        keteranganTC.setText("");
    }

    private void inisialAwalInputan1() {
        usernameloginTF.setText("");
        passwordloginTF.setText("");
    }

    @Override
    public void initialize(URL url, ResourceBundle rb) {

       inisialAwalInputan();
       setData();
       loadData1();
    }

    @FXML
    public void daftar(ActionEvent event) throws IOException {

        Parent root = FXMLLoader.load(getClass().getResource("/org/abs/view/AbsensiSDaftar.fxml"));
        Stage stage = new Stage();
        stage.setScene(new Scene(root));
        stage.show();
         }

    @FXML
    public void login(ActionEvent event) throws IOException, Exception {
        String username = userNameTF.getText();
        String password = passwordTF.getText();
        String peran = (String) levelCB.getValue();


        if (daDao.login(username, password) && peran.equalsIgnoreCase("Mahasiswa"))
        {
            Kehadiran kehadiran = new Kehadiran(null,username,LocalDate.now().toString()+daDao.getWaktu().toString());
            KehadiranDaoImpl kehadiranDao =  new KehadiranDaoImpl();
            kehadiranDao.saveDataKehadiran(kehadiran);
            JOptionPane.showMessageDialog(null,"Hai kamu "+userNameTF.getText()+ " berhasil masuk " + "\t Jam : " + akunDao.getWaktu() + "\nTanggal Sekarang" + akunDao.getTanggal());
             loadData1();
             ((Node)(event.getSource())).getScene().getWindow().hide();
            d.raiseWindow(5);


        }
        else if (akunDao.login(username, password) && peran.equalsIgnoreCase("Admin"))
        {
            JOptionPane.showMessageDialog(null,"Hai kamu Admin "+userNameTF.getText()+ " berhasil masuk " + "\t Jam : " + akunDao.getWaktu() + "\nTanggal Sekarang" + akunDao.getTanggal());
             loadData1();
             ((Node)(event.getSource())).getScene().getWindow().hide();
            d.raiseWindow(6);


        }
        else if (username.equals("admin") && (password.equals("admin"))&&peran.equalsIgnoreCase("Admin"))
       {
                JOptionPane.showMessageDialog(null, "berhasil masuk " + "\tWaktu Sekarang" + akunDao.getWaktu() + "\nTanggal Sekarang" + akunDao.getTanggal());
               // loadData();
                ((Node)(event.getSource())).getScene().getWindow().hide();
                d.raiseWindow(6);
      }
         else if (username.equals("") && (password.equals(""))) {
            JOptionPane.showMessageDialog(null, "Silahkan masukkan username dan pasword yang benar");
            ((Node)(event.getSource())).getScene().getWindow().hide();
            d.raiseWindow(1);
        }
        else {
            JOptionPane.showMessageDialog(null, "gagal masuk \n Perhatikan penggunaan Huruf besar dan kecil \n atau pemilihan level anda");
        }
    }
}
