/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package org.abs.controller;

import java.io.IOException;
import java.net.URL;
import java.util.List;
import java.util.ResourceBundle;
import javafx.collections.FXCollections;
import javafx.collections.ObservableList;
import javafx.event.ActionEvent;
import javafx.fxml.FXML;
import javafx.fxml.FXMLLoader;
import javafx.fxml.Initializable;
import javafx.scene.Node;
import javafx.scene.Parent;
import javafx.scene.Scene;
import javafx.scene.control.Alert;
import javafx.scene.control.Button;
import javafx.scene.control.ComboBox;
import javafx.scene.control.DialogPane;
import javafx.scene.control.Label;
import javafx.scene.control.TableColumn;
import javafx.scene.control.TableView;
import javafx.scene.control.TextField;
import javafx.scene.control.cell.PropertyValueFactory;
import javafx.stage.Stage;
import org.abs.dao.AkunDao;
import org.abs.dao.impl.AkunDaoImpl;
import org.abs.driver.Driver;
import org.abs.model.Akun;

/**
 *
 * @author norlinapasaribu
 */
public class DaftarSController implements Initializable{
    @FXML
    private TextField userNameDaftarTF;
    @FXML
    private TextField passwordDaftarTF;
    @FXML
    private Button Daftar;
    @FXML
    private Button Back;
     @FXML
    private Button Reset;

    ObservableList<Akun> dataPendaftaran;
    private AkunDao akunDao;
    @FXML
    private TableColumn<AkunDaoImpl, String> userName;
    @FXML
    private TableColumn<AkunDaoImpl, String> password;
    @FXML
    private TableView<Akun> daftarTB;

     private void inisialAwalInputan() {
        userNameDaftarTF.setText("");
        passwordDaftarTF.setText("");
    }


     public void loadData() {
        List<Akun> akuns = akunDao.getAllPendaftaran();
        dataPendaftaran = FXCollections.observableArrayList(akuns);
        userName.setCellValueFactory(new PropertyValueFactory<AkunDaoImpl, String>("userName"));
        password.setCellValueFactory(new PropertyValueFactory<AkunDaoImpl, String>("password"));
        daftarTB.setItems(dataPendaftaran);
    }

     public void daftar(ActionEvent event) throws IOException {
        String username = userNameDaftarTF.getText();
        String password = passwordDaftarTF.getText();
        Akun akun = new Akun (username, password);
        akunDao.saveDataAkun(akun);
        inisialAwalInputan();
        loadData();
    }

    @Override
    public void initialize(URL location, ResourceBundle resources) {

        loadData();
        inisialAwalInputan();
//        bar.setData(getData());
    }



}
