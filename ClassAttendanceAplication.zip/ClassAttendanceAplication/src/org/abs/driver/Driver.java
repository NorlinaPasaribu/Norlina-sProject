/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package org.abs.driver;

import java.io.IOException;
import javafx.application.Application;
import static javafx.application.Application.launch;
import javafx.fxml.FXMLLoader;
import javafx.scene.Parent;
import javafx.scene.Scene;
import javafx.stage.Stage;

/**
 *
 * @author norlinapasaribu
 */


public class Driver extends Application
{
    
    private Stage stage = new Stage();
    
    @Override
    public void start(Stage stage) throws IOException, Exception 
    {
        raiseWindow(5); 
    }
    
    public void raiseWindow(int type) throws IOException, Exception 
    {
        if(type==1)
        {
            //Stage stage1 = new Stage();
            Parent root = FXMLLoader.load(getClass().getResource("/org/abs/view/TampilanAwalAbsensiServer.fxml"));
            Scene scene = new Scene(root);
            stage.setScene(scene);
            stage.show();
            //stage1 = this.stage1;
        }
        else if(type==2)
        {   
            //Stage stage2 = new Stage();
            Parent root = FXMLLoader.load(getClass().getResource("/org/abs/view/TampilanDataAbsensiServer.fxml"));
            Scene scene = new Scene(root);
            stage.setScene(scene);
            stage.show(); 
            //stage2 = this.stage;
        }
        else if(type==3)
        { 
            //Stage stage3 = new Stage();
            Parent root = FXMLLoader.load(getClass().getResource("/org/abs/view/TampilanDataMahasiswa.fxml"));
            Scene scene = new Scene(root);
            stage.setScene(scene);
            stage.show(); 
            //stage3 = this.stage;
        }
//        else if(type==4)
//        {
//            VideoPlayer vp = new VideoPlayer();
//            vp.play();
//        }
        else if(type==5)
        {
            Parent parent =
                FXMLLoader.load(getClass().getResource("/org/abs/view/AbsensiSLogin.fxml"));
        Scene scene = new Scene(parent, 1000, 550);
        stage.setScene(scene);
        stage.show();
        }
        else if(type==6)
        {
            //Stage stage6 = new Stage();
            Parent root = FXMLLoader.load(getClass().getResource("/org/abs/view/UtamaKwatry.fxml"));
            Scene scene = new Scene(root);
            stage.setScene(scene);
            stage.show(); 
            //stage6 = this.stage;
        }
            
    }
    
    public static void main(String[] args) 
    {
        launch(args);
    }


}
