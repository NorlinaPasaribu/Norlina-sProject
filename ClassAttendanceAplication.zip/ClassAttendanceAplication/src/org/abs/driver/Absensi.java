/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package org.abs.driver;

import javafx.application.Application;
import javafx.application.Platform;
import javafx.event.EventHandler;
import javafx.fxml.FXMLLoader;
import javafx.scene.Parent;
import javafx.scene.Scene;
import javafx.stage.Stage;
import javafx.stage.WindowEvent;

/**
 *
 * @author norlinapasaribu
 */
public class Absensi extends Application {
     @Override
    public void start(Stage primaryStage) throws Exception 
    {
        Parent parent =
        FXMLLoader.load(getClass().getResource("/org/abs/view/AbsensiSLogin.fxml"));
        Scene scene = new Scene(parent, 1000, 550);
        primaryStage.setScene(scene);
        primaryStage.show();
        
        //stop running
        primaryStage.setOnCloseRequest(new EventHandler<WindowEvent>() {
            @Override
            public void handle(WindowEvent t) {
                Platform.exit();
                System.exit(0);
            }
        });
    }
}
