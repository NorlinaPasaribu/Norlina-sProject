/*
SQLyog Community v12.12 (64 bit)
MySQL - 5.6.21 : Database - absensi_kelas
*********************************************************************
*/

/*!40101 SET NAMES utf8 */;

/*!40101 SET SQL_MODE=''*/;

/*!40014 SET @OLD_UNIQUE_CHECKS=@@UNIQUE_CHECKS, UNIQUE_CHECKS=0 */;
/*!40014 SET @OLD_FOREIGN_KEY_CHECKS=@@FOREIGN_KEY_CHECKS, FOREIGN_KEY_CHECKS=0 */;
/*!40101 SET @OLD_SQL_MODE=@@SQL_MODE, SQL_MODE='NO_AUTO_VALUE_ON_ZERO' */;
/*!40111 SET @OLD_SQL_NOTES=@@SQL_NOTES, SQL_NOTES=0 */;
CREATE DATABASE /*!32312 IF NOT EXISTS*/`absensi_kelas` /*!40100 DEFAULT CHARACTER SET latin1 */;

USE `absensi_kelas`;

/*Table structure for table `akun` */

DROP TABLE IF EXISTS `akun`;

CREATE TABLE `akun` (
  `userName` varchar(30) NOT NULL,
  `password` varchar(30) NOT NULL,
  PRIMARY KEY (`userName`)
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

/*Data for the table `akun` */

insert  into `akun`(`userName`,`password`) values ('',''),('admin','admin'),('nur','pass'),('rudi','rudi'),('rudi1','rudi1'),('rudi2','rudi2'),('rudi3','rudi3');

/*Table structure for table `dataabsensi` */

DROP TABLE IF EXISTS `dataabsensi`;

CREATE TABLE `dataabsensi` (
  `idDataAbsensi` varchar(30) NOT NULL,
  `Nama` varchar(30) NOT NULL,
  `Password` varchar(30) NOT NULL,
  PRIMARY KEY (`idDataAbsensi`)
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

/*Data for the table `dataabsensi` */

insert  into `dataabsensi`(`idDataAbsensi`,`Nama`,`Password`) values ('11S14001','Dewi','11S14001'),('11S14002','Justin','11S14002'),('11S14003','Giovani','11S14003'),('11S14004','Oktavi','11S14004'),('11S14005','Romasi','11S14005'),('11S14006','Desi','11S14006'),('11S14007','Yosepina','11S14007'),('11S14008','Kwatri','11S14008'),('11S14009','Ranti','11S14009'),('11S14010','Norlina','11S14010'),('11S14011','Budi','11S14011'),('11S14012','Esri','11S14012'),('11S14013','Astri','11S14013'),('11S14014','Angel','11S14014'),('11S14015','Grace','11S14015'),('11S14016','Daniel','11S14016'),('11S14017','Amanda','11S14017'),('11S14018','Talenta','11S14018'),('11S14019','Minarni','11S14019'),('11S14020','Davit','11S14020'),('11S14021','Dian','11S14021'),('11S14022','Paul','11S14022'),('11S14023','Melvandito','11S14023'),('11S14024','Daniel','11S14024'),('11S14025','Gracia','11S14025'),('11S14026','Sandro','11S14026'),('11S14027','Helkia','11S14027'),('11S14028','Lily','11S14028'),('11S14029','Betty','11S14029'),('11S14030','Ivan','11S14030');

/*Table structure for table `kehadiran` */

DROP TABLE IF EXISTS `kehadiran`;

CREATE TABLE `kehadiran` (
  `No` int(30) NOT NULL AUTO_INCREMENT,
  `Mahasiswa` varchar(20) NOT NULL,
  `Keterangan` varchar(20) NOT NULL,
  PRIMARY KEY (`No`)
) ENGINE=InnoDB AUTO_INCREMENT=7 DEFAULT CHARSET=latin1;

/*Data for the table `kehadiran` */

insert  into `kehadiran`(`No`,`Mahasiswa`,`Keterangan`) values (1,'11S14010',''),(2,'11S14011',''),(3,'11S14010','2016-06-13'),(4,'11S14001','2016-06-1312:33:02'),(5,'11S14010','2016-06-1314:44:12'),(6,'11S14003','2016-06-1315:22:30');

/*Table structure for table `peran` */

DROP TABLE IF EXISTS `peran`;

CREATE TABLE `peran` (
  `idPeran` varchar(30) NOT NULL,
  `namaPeran` varchar(30) NOT NULL,
  PRIMARY KEY (`idPeran`)
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

/*Data for the table `peran` */

/*Table structure for table `user` */

DROP TABLE IF EXISTS `user`;

CREATE TABLE `user` (
  `Id` varchar(30) NOT NULL,
  `Nama` varchar(30) NOT NULL,
  `Alamat` varchar(30) NOT NULL,
  `Pekerjaan` varchar(30) NOT NULL,
  `Jenis Kelamin` varchar(30) NOT NULL,
  `Tanggal Lahir` varchar(30) NOT NULL,
  PRIMARY KEY (`Id`)
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

/*Data for the table `user` */

/*!40101 SET SQL_MODE=@OLD_SQL_MODE */;
/*!40014 SET FOREIGN_KEY_CHECKS=@OLD_FOREIGN_KEY_CHECKS */;
/*!40014 SET UNIQUE_CHECKS=@OLD_UNIQUE_CHECKS */;
/*!40111 SET SQL_NOTES=@OLD_SQL_NOTES */;
