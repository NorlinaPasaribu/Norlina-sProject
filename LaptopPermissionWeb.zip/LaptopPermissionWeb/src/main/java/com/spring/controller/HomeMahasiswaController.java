package com.spring.controller;

import com.spring.dao.RequestDao;
import com.spring.model.Request;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;

@Controller
public class HomeMahasiswaController {
	private RequestDao rDao;
	
	@Autowired
	public void setrDao(RequestDao rDao) {
		this.rDao = rDao;
	}
	@RequestMapping(value = "/createRequest", method = RequestMethod.POST)
	public String createRequest(Model model, Request request){
		model.addAttribute("request", rDao.saveOrUpdate(request));
		return "redirect:/izinlaptop/mahasiswa";
	}
	
	
}
