package com.spring.controller;


import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.RequestMapping;

import com.spring.dao.RequestDao;


@Controller
public class HomeDuktekController {

	private RequestDao rDao;

	@Autowired
	public void setrDao(RequestDao rDao) {
		this.rDao = rDao;
	}

	@RequestMapping(value = "/updateRequest/{id}")
	public String updateRequest(@PathVariable int id) {
		rDao.updateStatusRequestById(id);
		return "redirect:/izinlaptop/duktek";
	}

}
