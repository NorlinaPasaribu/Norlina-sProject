package com.spring.controller;

import javax.servlet.http.HttpServletRequest;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;

import com.spring.dao.AkunDao;
import com.spring.dao.RequestDao;
import com.spring.model.Akun;
import com.spring.model.Request;

@Controller
public class IndexController {
	private AkunDao aDao;
	private RequestDao rDao;
	private Akun akunLogin;

	@Autowired
	public void setuDao(AkunDao aDao) {
		this.aDao = aDao;
	}
	@Autowired
	public void setrDao(RequestDao rDao) {
		this.rDao = rDao;
	}
	
	@RequestMapping("/izinlaptop")
	public String index(Model model) {
		model.addAttribute("akun", new Akun());
		model.addAttribute("akunLogin",new Akun());
		return "index";
	}

	@RequestMapping("/izinlaptop/mahasiswa")
	public String homeMahasiswa(Model model) {
		Request request = new Request();
		request.setId_mahasiswa(akunLogin.getId());
		request.setNama_mahasiswa(akunLogin.getUsername());
		request.setStatus("NO");
		model.addAttribute("request", request);
		model.addAttribute("allRequest", rDao.getAllRequestByIdMahasiswa(akunLogin.getId()));
		model.addAttribute("akunLogin",akunLogin);
		return "homeMahasiswa";
	}

	@RequestMapping("/izinlaptop/duktek")
	public String homeDuktek(Model model) {
		model.addAttribute("allRequest",rDao.getAllRequestByStatus("NO"));
		model.addAttribute("akunLogin",akunLogin);
		return "homeDuktek";
	}

	@RequestMapping("/izinlaptop/satpam")
	public String homeSatpam(Model model) {
		model.addAttribute("allRequest",rDao.getAllRequestByStatus("YES"));
		model.addAttribute("akunLogin",akunLogin);
		return "homeSatpam";
	}

	@RequestMapping(value = "/createAkun", method = RequestMethod.POST)
	public String saveOrUpdateAkun(Model model, Akun akun) {
		model.addAttribute("akun", aDao.saveOrUpdate(akun));
		return "redirect:/izinlaptop";
	}

	@RequestMapping(value = "/login", method = RequestMethod.POST)
	public String login(HttpServletRequest request) {
		String username = request.getParameter("user");
		String password = request.getParameter("pass");
		if(aDao.login(username, password) != null){
			request.getSession().setAttribute("akunLogin", aDao.login(username, password));
			akunLogin = (Akun) request.getSession().getAttribute("akunLogin");
			if (akunLogin.getRole().equals("Mahasiswa")) {
				return "redirect:/izinlaptop/mahasiswa";
			} else if (akunLogin.getRole().equals("Duktek")) {
				return "redirect:/izinlaptop/duktek";
			} else if (akunLogin.getRole().equals("Satpam")) {			
				return "redirect:/izinlaptop/satpam";
			} 
		}		
		return "redirect:/izinlaptop";
	}
	@RequestMapping("/logout")
	public String logout(HttpServletRequest request){
		request.getSession().removeAttribute("akunLogin");
		return "redirect:/izinlaptop";
	}

}
