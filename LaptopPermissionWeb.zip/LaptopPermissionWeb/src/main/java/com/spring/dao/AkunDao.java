package com.spring.dao;

import java.util.List;

import com.spring.model.Akun;


public interface AkunDao {
	List<Akun> getAllAkun();
	Akun saveOrUpdate(Akun akun);
	Akun login(String username, String password);
}
