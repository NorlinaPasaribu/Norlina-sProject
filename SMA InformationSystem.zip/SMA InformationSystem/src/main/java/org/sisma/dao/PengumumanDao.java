package org.sisma.dao;

import org.sisma.models.Pengumuman;

public interface PengumumanDao {
	
	Pengumuman saveOrUpdate(Pengumuman pengumuman);

}
